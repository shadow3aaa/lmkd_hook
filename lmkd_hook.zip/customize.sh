SKIPUNZIP=0

# permission
chmod a+x $MODPATH/inject

